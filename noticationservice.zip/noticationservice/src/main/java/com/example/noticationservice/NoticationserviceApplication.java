package com.example.noticationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoticationserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoticationserviceApplication.class, args);
	}

}
